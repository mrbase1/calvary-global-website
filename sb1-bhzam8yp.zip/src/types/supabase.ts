export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          full_name: string
          role: 'member' | 'pastor' | 'minister' | 'admin'
          avatar_url: string | null
          phone: string | null
        }
        Insert: {
          id: string
          created_at?: string
          updated_at?: string
          full_name: string
          role?: 'member' | 'pastor' | 'minister' | 'admin'
          avatar_url?: string | null
          phone?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          updated_at?: string
          full_name?: string
          role?: 'member' | 'pastor' | 'minister' | 'admin'
          avatar_url?: string | null
          phone?: string | null
        }
      }
      prayer_requests: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          title: string
          description: string
          category: string
          status: 'pending' | 'in_progress' | 'completed'
          is_anonymous: boolean
          user_id: string
        }
        Insert: {
          id?: string
          created_at?: string
          updated_at?: string
          title: string
          description: string
          category: string
          status?: 'pending' | 'in_progress' | 'completed'
          is_anonymous?: boolean
          user_id: string
        }
        Update: {
          id?: string
          created_at?: string
          updated_at?: string
          title?: string
          description?: string
          category?: string
          status?: 'pending' | 'in_progress' | 'completed'
          is_anonymous?: boolean
          user_id?: string
        }
      }
      events: {
        Row: {
          id: string
          title: string
          description: string
          start_time: string
          end_time: string
          location: string
          type: 'in_person' | 'online' | 'hybrid'
          max_attendees: number | null
          needs_volunteers: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          description: string
          start_time: string
          end_time: string
          location: string
          type: 'in_person' | 'online' | 'hybrid'
          max_attendees?: number | null
          needs_volunteers?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string
          start_time?: string
          end_time?: string
          location?: string
          type?: 'in_person' | 'online' | 'hybrid'
          max_attendees?: number | null
          needs_volunteers?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      event_registrations: {
        Row: {
          id: string
          event_id: string
          user_id: string
          registration_type: 'attendee' | 'volunteer'
          status: 'pending' | 'confirmed' | 'cancelled'
          created_at: string
        }
        Insert: {
          id?: string
          event_id: string
          user_id: string
          registration_type: 'attendee' | 'volunteer'
          status?: 'pending' | 'confirmed' | 'cancelled'
          created_at?: string
        }
        Update: {
          id?: string
          event_id?: string
          user_id?: string
          registration_type?: 'attendee' | 'volunteer'
          status?: 'pending' | 'confirmed' | 'cancelled'
          created_at?: string
        }
      }
    }
  }
}