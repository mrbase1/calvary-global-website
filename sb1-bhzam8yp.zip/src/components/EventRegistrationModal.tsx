import React from 'react';
import { useForm } from 'react-hook-form';
import { X, Calendar, MapPin, Users, Clock } from 'lucide-react';
import { format } from 'date-fns';
import type { Database } from '../types/supabase';

type Event = Database['public']['Tables']['events']['Row'];

interface EventRegistrationModalProps {
  event: Event;
  onClose: () => void;
  onRegister: (registrationType: 'attendee' | 'volunteer') => Promise<void>;
  isRegistered: boolean;
  isVolunteering: boolean;
}

export function EventRegistrationModal({
  event,
  onClose,
  onRegister,
  isRegistered,
  isVolunteering,
}: EventRegistrationModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleRegister = async (type: 'attendee' | 'volunteer') => {
    setIsSubmitting(true);
    try {
      await onRegister(type);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-lg w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <X className="h-6 w-6" />
        </button>

        <h2 className="text-2xl font-bold text-gray-900 mb-4">{event.title}</h2>
        
        <div className="space-y-4 mb-6">
          <p className="text-gray-600">{event.description}</p>
          
          <div className="flex items-center text-gray-600">
            <Calendar className="h-5 w-5 mr-2" />
            <span>
              {format(new Date(event.start_time), 'PPP')}
            </span>
          </div>
          
          <div className="flex items-center text-gray-600">
            <Clock className="h-5 w-5 mr-2" />
            <span>
              {format(new Date(event.start_time), 'p')} - {format(new Date(event.end_time), 'p')}
            </span>
          </div>
          
          <div className="flex items-center text-gray-600">
            <MapPin className="h-5 w-5 mr-2" />
            <span>{event.location}</span>
          </div>
          
          {event.max_attendees && (
            <div className="flex items-center text-gray-600">
              <Users className="h-5 w-5 mr-2" />
              <span>Maximum {event.max_attendees} attendees</span>
            </div>
          )}
        </div>

        <div className="space-y-3">
          {!isRegistered && !isVolunteering && (
            <>
              <button
                onClick={() => handleRegister('attendee')}
                disabled={isSubmitting}
                className="w-full bg-purple-600 text-white py-2 px-4 rounded-md hover:bg-purple-700 disabled:opacity-50"
              >
                Register to Attend
              </button>
              
              {event.needs_volunteers && (
                <button
                  onClick={() => handleRegister('volunteer')}
                  disabled={isSubmitting}
                  className="w-full border border-purple-600 text-purple-600 py-2 px-4 rounded-md hover:bg-purple-50 disabled:opacity-50"
                >
                  Volunteer for This Event
                </button>
              )}
            </>
          )}
          
          {(isRegistered || isVolunteering) && (
            <p className="text-center text-green-600 font-medium">
              You are {isVolunteering ? 'volunteering for' : 'registered for'} this event
            </p>
          )}
        </div>
      </div>
    </div>
  );
}