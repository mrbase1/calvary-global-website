import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Globe, Users, Calendar } from 'lucide-react';

export function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section
        className="relative bg-cover bg-center py-32"
        style={{
          backgroundImage:
            'url("https://images.unsplash.com/photo-1445905595283-21f8ae8a33d2?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80")',
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Uniting Hearts in Global Prayer
          </h1>
          <p className="text-xl text-white mb-8 max-w-2xl mx-auto">
            Join our community of believers dedicated to praying for peace,
            unity, and progress across Nigeria and the United States.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/prayer-requests"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700"
            >
              Submit Prayer Request
            </Link>
            <Link
              to="/join"
              className="inline-flex items-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-white hover:text-purple-600"
            >
              Join Our Community
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-purple-100 text-purple-600 mb-4">
                <Heart className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Prayer Requests</h3>
              <p className="text-gray-600">
                Submit and join in prayer for needs around the world
              </p>
            </div>
            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-purple-100 text-purple-600 mb-4">
                <Globe className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Global Impact</h3>
              <p className="text-gray-600">
                Connecting believers across continents
              </p>
            </div>
            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-purple-100 text-purple-600 mb-4">
                <Users className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Community</h3>
              <p className="text-gray-600">
                Join a network of passionate believers
              </p>
            </div>
            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center h-12 w-12 rounded-md bg-purple-100 text-purple-600 mb-4">
                <Calendar className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Events</h3>
              <p className="text-gray-600">
                Participate in prayer meetings and healing services
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white dark:bg-gray-900">
        <div className="py-8 px-20 mx-auto max-w-screen-xl lg:py-16 lg:px-6">
          <div className="max-w-screen-lg text-gray-500 sm:text-lg dark:text-gray-400">
            <h2 className="mb-4 text-4xl tracking-tight font-bold text-gray-900 dark:text-white">
              A Prayer Network targeted at promoting the{' '}
              <span className="font-extrabold">peace, unity and progress</span>{' '}
              of Nations
            </h2>
            <p className="mb-4 font-light">
              Calvary Global Prayer and Healing Centre Nigeria is a Prayer
              network, comprising pastors, ordained ministers of the bible, and
              prayer-loving believers who converge to pray for the peace, unity,
              and progress of our dear nation Nigeria, going from city to city.
            </p>
            <p className="mb-4 font-medium">
              Supported by Calvary Global Outreach Ministries, USA, and convened
              by{' '}
              <Link
                to="#"
                className="text-base font-medium text-purple-600 hover:text-gray-600"
              >
                Rev. Godswill Keenam
              </Link>
              .
            </p>
            <a
              href="#"
              className="inline-flex items-center font-medium text-primary-600 hover:text-primary-800 dark:text-primary-500 dark:hover:text-primary-700"
            >
              <Link
                to="#"
                className="font-medium text-purple-400 hover:text-gray-600"
              >
                Learn more
              </Link>
              <svg
                className="ml-1 w-6 h-6"
                fill="currentColor"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill-rule="evenodd"
                  d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                  clip-rule="evenodd"
                ></path>
              </svg>
            </a>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-purple-700 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Join Our Prayer Movement
          </h2>
          <p className="text-xl text-purple-100 mb-8 max-w-2xl mx-auto">
            Together, we can make a difference through the power of prayer.
          </p>
          <Link
            to="/register"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-purple-700 bg-white hover:bg-purple-50"
          >
            Get Started Today
          </Link>
        </div>
      </section>

      {/* National Day of Prayer */}
      <section className="bg-gradient-to-r from-blue-200 to-purple-200 rounded-lg shadow-md py-10 px-6 md:px-12 lg:px-24">
        <div className="container mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="text-content space-y-4">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-semibold text-gray-800">
              Pray For Nigeria!
            </h2>
            <p className="text-gray-700 text-base md:text-lg lg:text-xl">
              On the 31st of September every year, we hold the National Day of
              Prayer in Abuja and other states, as a precursor to Nigeria's
              Independence Day on 1st October.
            </p>
            <Link
              to="/register"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-purple-700 bg-white hover:bg-purple-50 border-2 border-purple-200"
            >
              Get Started Today
            </Link>
          </div>
          <div className="image-content grid grid-cols-2 gap-4">
            <div className="rounded-lg overflow-hidden shadow-md">
              <img
                src={require('../assets/cgphc-image.jpg')}
                alt="Image 1"
                className="w-full h-auto object-cover"
              />
            </div>
            <div className="rounded-lg overflow-hidden shadow-md">
              <img
                src="../assets/national-day-of-prayer.jpg"
                alt="Image 2"
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
